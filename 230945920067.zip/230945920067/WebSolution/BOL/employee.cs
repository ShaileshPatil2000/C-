namespace BOL;
public class employee{
    public int eid{get;set;}
    public string ename{get;set;}
    public string date{get;set;}
    public string work_desc{get;set;}
     public int duration{get;set;}

    public string status{get;set;}
    public employee(int eid, string ename, string date, string work_desc,
    int duration,string status){
        this.eid = eid;
        this.ename = ename;
        this.date = date;
        this.work_desc = work_desc;
        this.duration=duration;
        this.status=status;
    }
}