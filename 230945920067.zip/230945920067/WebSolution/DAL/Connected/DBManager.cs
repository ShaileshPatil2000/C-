namespace DAL.Connected;
using BOL;
using MySql.Data.MySqlClient;
public class DBManager{
    public static string connectionstring = @"server=localhost;port=3306;user=dac24;password=welcome;database=dac24";

    public static List<employee> GetAllEmplyees(){
        List<employee> list = new List<employee>();
        MySqlConnection connection = new MySqlConnection();
        connection.ConnectionString = connectionstring;
        string query = "select * from employees";
        MySqlCommand command = new MySqlCommand(query, connection);
        try{
            connection.Open();
            MySqlDataReader reader = command.ExecuteReader();
            while(reader.Read()){
              
                int eid = int.Parse(reader["eid"].ToString());
                string ename = reader["ename"].ToString();
                string date = reader["Date"].ToString();
                string work_desc = reader["work_desc"].ToString();
                 int duration = int.Parse(reader["duration"].ToString());
                 string status = reader["status"].ToString();
               
              
                list.Add(new employee(eid,ename,date,work_desc,duration,status));
            }
        
            reader.Close();
        }

        // }catch(Exception e){
        //     Console.WriteLine(e.message);
        // }
        finally{
            connection.Close();
        }
        return list;
    }

    public static void insertData(string eid, string ename, string Date, string work_desc,string duration,string status){
        string query = "insert into employees values(@eid, @ename, @Date, @work_desc,@duration,@status)";
        MySqlConnection connection = new MySqlConnection();
        connection.ConnectionString = connectionstring;
        MySqlCommand command = new MySqlCommand(query, connection);
        command.Parameters.AddWithValue("@eid", int.Parse(eid));
        command.Parameters.AddWithValue("@ename", ename);
        command.Parameters.AddWithValue("@Date", Date);
        command.Parameters.AddWithValue("@work_desc", work_desc);
        command.Parameters.AddWithValue("@duration", int.Parse(duration));
      command.Parameters.AddWithValue("@status", status);
        connection.Open();
        int n = command.ExecuteNonQuery();
        if(n > 0){
            Console.WriteLine("Employee Inserted at "+eid);
        }
        connection.Close();
    }
    public static void updateData(string eid, string ename){
        string query = "update employees set ename=@ename where eid=@eid";
        MySqlConnection connection = new MySqlConnection();
        connection.ConnectionString = connectionstring;
        MySqlCommand command = new MySqlCommand(query, connection);
        command.Parameters.AddWithValue("@eid", int.Parse(eid));
        command.Parameters.AddWithValue("@ename", ename);
         connection.Open();
        int n = command.ExecuteNonQuery();
        if(n > 0){
            Console.WriteLine("Employee Updated at "+eid);
        }
        connection.Close();
    }

    public static void deleteData(string eid){
        string query = "delete from employees where eid="+eid;
        MySqlConnection connection = new MySqlConnection();
        connection.ConnectionString = connectionstring;
        MySqlCommand command = new MySqlCommand(query, connection);
        // command.Parameters.AddWithValue("@pid", pid);
        connection.Open();
        command.ExecuteNonQuery();
        connection.Close();
    }
}