﻿namespace BLL;

public class Class1
{

}
