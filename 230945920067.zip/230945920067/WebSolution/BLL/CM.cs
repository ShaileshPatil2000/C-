namespace BLL;
using BOL;
using DAL.Connected;
public class CM{
    public List<employee> GetAllemployees(){
        List<employee> allemployees = new List<employee>();
        allemployees = DBManager.GetAllemployees();
        return allemployees;
    }
}