using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Portal.Models;
using DAL.Connected;

namespace Portal.Controllers;
//namespace System.Collections;
public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        Employee e1 = new Employee{eid = 12, ename= "Shailesh", Date="2021-12-21", };
     

        List<Employee> family = new List<Employee>();
        family.Add(e1);
    

        this.ViewData["bfamily"] = family;
        return View();
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [HttpGet]
    public IActionResult Register(){
        return View();
    }

    [HttpPost]
    public IActionResult Register(string ProductId, string ProductName, string ProductPrice, string ProductQuantity){
        Console.WriteLine(ProductId + " " + ProductName + " " +ProductPrice + " " + ProductQuantity);
        DBManager.insertData(ProductId, ProductName, ProductPrice, ProductQuantity);
        return View();
    }
     [HttpGet]
    public IActionResult Update(){
        return View();
    }

    [HttpPost]
    public IActionResult Update(string ProductId, string ProductName){
        Console.WriteLine(ProductId + " " + ProductName);
        DBManager.updateData(ProductId, ProductName);
        return View();
    }
    [HttpGet]
    public IActionResult Delete(){
        return View();
    }
    [HttpPost]
    public IActionResult Delete(string ProductId){
        DBManager.deleteData(ProductId);
        return View();
    }

    [HttpGet]
    public IActionResult Login(){
        return View();
    }

    [HttpPost]
    public IActionResult Login(string userName, string password){
        Console.WriteLine(userName + " " + password);
        return View();
    }
}
