namespace Portal.Models;

public class Employee{
    public int eid{get;set;}
    public string ename{set;get;}
  
  
}