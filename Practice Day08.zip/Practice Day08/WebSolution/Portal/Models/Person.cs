namespace Portal.Models;

public class Person{
    public int Id{get;set;}
    public string First_Name{set;get;}
    public string Last_Name{set;get;}
  
}