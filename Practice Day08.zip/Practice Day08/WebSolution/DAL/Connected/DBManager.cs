namespace DAL.Connected;
using BOL;
using MySql.Data.MySqlClient;
public class DBManager{
    public static string connectionstring = @"server=localhost;port=3306;user=root;password=hello;database=demo";

    public static List<Product> GetAllProducts(){
        List<Product> list = new List<Product>();
        MySqlConnection connection = new MySqlConnection();
        connection.ConnectionString = connectionstring;
        string query = "select * from products";
        MySqlCommand command = new MySqlCommand(query, connection);
        try{
            connection.Open();
            MySqlDataReader reader = command.ExecuteReader();
            while(reader.Read()){
              
                int id = int.Parse(reader["prod_id"].ToString());
                string name = reader["prod_name"].ToString();
                int up = int.Parse(reader["unit_price"].ToString());
                int qty = int.Parse(reader["quantity"].ToString());
              
                list.Add(new Product(id,name,up,qty));
            }
        
            reader.Close();
        }

        // }catch(Exception e){
        //     Console.WriteLine(e.message);
        // }
        finally{
            connection.Close();
        }
        return list;
    }

    public static void insertData(string pid, string pname, string price, string qty){
        string query = "insert into products values(@pid, @pname, @price, @qty)";
        MySqlConnection connection = new MySqlConnection();
        connection.ConnectionString = connectionstring;
        MySqlCommand command = new MySqlCommand(query, connection);
        command.Parameters.AddWithValue("@pid", int.Parse(pid));
        command.Parameters.AddWithValue("@pname", pname);
        command.Parameters.AddWithValue("@price", int.Parse(price));
        command.Parameters.AddWithValue("@qty", int.Parse(qty));
        connection.Open();
        int n = command.ExecuteNonQuery();
        if(n > 0){
            Console.WriteLine("Product Inserted at "+pid);
        }
        connection.Close();
    }
    public static void updateData(string pid, string pname){
        string query = "update products set prod_name=@pname where prod_id=@pid";
        MySqlConnection connection = new MySqlConnection();
        connection.ConnectionString = connectionstring;
        MySqlCommand command = new MySqlCommand(query, connection);
        command.Parameters.AddWithValue("@pid", int.Parse(pid));
        command.Parameters.AddWithValue("@pname", pname);
         connection.Open();
        int n = command.ExecuteNonQuery();
        if(n > 0){
            Console.WriteLine("Product Updated at "+pid);
        }
        connection.Close();
    }

    public static void deleteData(string pid){
        string query = "delete from products where prod_id="+pid;
        MySqlConnection connection = new MySqlConnection();
        connection.ConnectionString = connectionstring;
        MySqlCommand command = new MySqlCommand(query, connection);
        // command.Parameters.AddWithValue("@pid", pid);
        connection.Open();
        command.ExecuteNonQuery();
        connection.Close();
    }
}